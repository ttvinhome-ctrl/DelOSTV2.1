# DelOS TV

Launcher Google TV bergaya Apple TV: bersih, halus, dan profesional, dengan tema biru terang ala Mercedes. Kaca (glassmorphism), animasi booting lampu start, dan jendela pengaturan mengambang berisi ikon bulat yang bisa dikendalikan remote.

## v2.0 — Aurora Glass
Tampilan dirombak: tipografi tipis & lega, kaca lebih halus, dock berbentuk kapsul, lampu ambient yang berubah mengikuti warna aplikasi/film yang difokus, hero tanpa kotak, layar santai melayang, dan logo DelOS di animasi booting.

## v2.1 — Wallpaper Mercedes F1 online
Wallpaper beranda diambil otomatis dari internet: foto bertema Mercedes F1 berlisensi bebas (CC BY / CC BY-SA / CC0 / domain publik) lewat Wikimedia Commons, berganti tiap 45 detik, disimpan 24 jam, dengan kredit fotografer tampil di pojok kanan bawah. Offline atau gagal memuat: otomatis memakai wallpaper bawaan. Pilih/segarkan lewat Pengaturan > Wallpaper. Aplikasi sekarang memakai izin INTERNET.

## Cara membuat APK (dari HP juga bisa)
1. Buat repo baru di GitHub, lalu unggah **seluruh isi** folder ini (termasuk folder `.github`).
2. Buka tab **Actions** → workflow **Build APK** berjalan otomatis (atau tekan *Run workflow*).
3. Setelah hijau, unduh `app-debug.apk` dari halaman **Releases** (atau dari *Artifacts*).

## Memasang di TV
```
adb connect IP_TV:5555
adb install -r app-debug.apk
adb shell cmd package set-home-activity id.delos.tv/.MainActivity
```
Launcher bawaan tidak dinonaktifkan. Untuk kembali, copot pemasangan DelOS TV. Update: unggah perubahan ke GitHub, unduh APK baru, lalu `adb install -r` lagi (keystore tetap, jadi tidak perlu uninstall).

## Mengubah tampilan
Semua UI ada di `app/src/main/assets/index.html` (HTML/CSS/JS). Bisa dicoba langsung di browser: panah = geser, Enter = pilih, Esc = kembali.
- Data demo (film, waktu sholat, cuaca) ada di bagian atas script: ganti dengan data asli.
- Wallpaper ada di `assets/img/`.
- Jembatan ke Android ada di `MainActivity.java`: `launch`, `openSettings`, `setVolume`, `apps`.

Catatan: keystore (`app/delos.keystore`) sengaja disertakan untuk proyek pribadi; jangan dipakai untuk rilis publik.
