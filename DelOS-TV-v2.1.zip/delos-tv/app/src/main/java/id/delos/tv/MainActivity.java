package id.delos.tv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Launcher DelOS TV: UI web (assets/index.html) di dalam WebView layar penuh. */
public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF04122B);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        web.requestFocus();
    }

    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    // Launcher tidak boleh keluar: tombol Kembali diteruskan ke UI.
    @Override public void onBackPressed() { js("window.onBack&&onBack()"); }

    // Tombol Home ditekan: kembali ke beranda.
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); js("window.onHome&&onHome()"); }

    private void js(String code) { web.evaluateJavascript(code, null); }

    private void open(Intent i) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
    }

    /** Dipanggil dari JavaScript sebagai objek "Android". */
    private class Bridge {
        @JavascriptInterface public void launch(String pkg) {
            runOnUiThread(() -> {
                PackageManager pm = getPackageManager();
                Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
                if (i == null) i = pm.getLaunchIntentForPackage(pkg);
                if (i != null) open(i);
            });
        }

        @JavascriptInterface public void openSettings(String key) {
            String a;
            switch (key) {
                case "wifi": a = Settings.ACTION_WIFI_SETTINGS; break;
                case "bluetooth": a = Settings.ACTION_BLUETOOTH_SETTINGS; break;
                case "apps": a = Settings.ACTION_APPLICATION_SETTINGS; break;
                case "storage": a = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
                default: a = Settings.ACTION_SETTINGS;
            }
            final String action = a;
            runOnUiThread(() -> {
                try { startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Exception e) { open(new Intent(Settings.ACTION_SETTINGS)); }
            });
        }

        @JavascriptInterface public void setVolume(int pct) {
            AudioManager m = (AudioManager) getSystemService(AUDIO_SERVICE);
            int max = m.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            m.setStreamVolume(AudioManager.STREAM_MUSIC, max * Math.max(0, Math.min(100, pct)) / 100, 0);
        }

        @JavascriptInterface public String apps() {
            PackageManager pm = getPackageManager();
            List<ResolveInfo> l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0);
            if (l.isEmpty()) l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
            List<String[]> r = new ArrayList<>();
            for (ResolveInfo ri : l)
                if (!ri.activityInfo.packageName.equals(getPackageName()))
                    r.add(new String[]{ri.loadLabel(pm).toString(), ri.activityInfo.packageName});
            Collections.sort(r, (x, y) -> x[0].compareToIgnoreCase(y[0]));
            JSONArray out = new JSONArray();
            try { for (String[] x : r) out.put(new JSONObject().put("n", x[0]).put("p", x[1])); } catch (Exception ignored) { }
            return out.toString();
        }
    }
}
